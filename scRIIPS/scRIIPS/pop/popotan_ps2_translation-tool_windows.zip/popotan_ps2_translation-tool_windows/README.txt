run to patch : xdelta3 -d -s Popotan.iso Popotan_English.xdelta Popotan_english.iso
notes:
The game may take a few seconds to load on emulators, so you might see a black screen during startup. Don't worry that's normal.
